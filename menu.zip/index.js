const menu = {
	'نوشیدنی گرم': [
		['اسپرسو' , '۳۸' , ''],
		['اسپرسو دبل' , '۴۵' , ''],
		['آمریکانو' , '۵۵' , ''],
		['کاپوچینو' , '۶۵' , ''],
		['لاته' , '۷۵' , ''],
		['موکا' , '۷۵' , ''],
		['کارامل ماکیاتو' , '۷۵' , ''],
		['چای ماسالا' , '۶۵' , ''],
		['هات چاکلت' , '۶۵' , ''],
		['فرنچ پرس' , '۷۰' , '']
	],
	'نوشیدنی سرد': [
		['موهیتو' , '۷۸' , ''],
		['لیموناد' , '۷۵' , ''],
		['آیس لاته' , '۷۸' , ''],
		['آیس آمریکانو' , '۵۵' , ''],
		['آیس موکا' , '۷۵' , '']
	],
	'شیک': [
		['شکلات' , '۱۰۵' , ''],
		['موز' , '۹۵' , ''],
		['کارامل' , '۹۵' , ''],
		['توت فرنگی' , '۹۵' , ''],
		['چیز کیک' , '۹۰' , ''],
		['ماسالا' , '۸۰' , '']
	],
	'پاستا': [
		['پاستا بلونز' , '۲۵۰' , 'اسپاگتی قارچ گوجه زیتون گوشت چرخ کرده پارمزان فلفل سبز'],
		['پاستا آلفردو' , '۲۱۵' , 'پنه قارچ مرغ زیتون سس آلفردو'],
		['پاستا عربیتا' , '۲۱۰' , 'اسپاگتی گوجه فرنگی ریحان زیتون پارمزان گردو']
	],
	'پیتزا': [
		['پتیزا مخصوص باغ کافه' , '۲۵۰' , 'تکه های مرغ تکه های گوشت زیتون قارچ کالباس مرغ و گوشت سس مخصوص'],
		['پتیزا گوشت و قارچ' , '۲۴۰' , 'گوشت گوساله قارچ سس مخصوص'],
		['پیتزا پپرونی' , '۲۷۵' , 'پپرونی پنیر پیتزا سس مخصوص'],
		['پیتزا سبزیجات' , '۲۳۰' , 'گوجه فرنگی قارچ ذرت فلفل دلمه ای سس قرمز']
	],
	'سوخاری': [
		['سیب زمینی مخصوص باغ کافه' , '۱۸۰' , ''],
		['سیب زمینی پنیری' , '۱۱۰' , ''],
		['سیب زمینی' , '۸۰' , '']
	],
	'ساندویچ': [
		['دوبل برگر' , '۲۸۵' , 'همبرگر پیاز کاراملی قارچ پنیر فیله مرغ گوجه کاهو سس مخصوص'],
		['چیز برگر' , '۲۴۰' , 'همبرگر دست ساز سرآشپز پیاز کاراملی پنیر ورقه ای کاهو گوجه فرهنگی سس مخصوص'],
		['قارچ برگر' , '۲۳۵' , 'همبرگر دست ساز سرآشپز قارچ و پنیر کاهو گوجه فرهنگی سس مخصوص'],
		['چیکن برگر' , '۲۲۵' , 'فیله مرغ قارچ و پنیر کاهو گوجه فرنگی سس مخصوص'],
		['همبرگر کلاسیک' , '۲۲۰' , 'همبرگر دست ساز سرآشپز پیاز کاراملی کاهو گوجه فرنگی سس مخصوص']
	],
	'سالاد': [
		['سالاد سزار' , '۱۹۹' , 'کاهو تکه های مرغ زیتون پنیر پارمزان سس مخصوص'],
		['سالاد یونانی' , '۱۵۰' , 'سبزی معطر گوجه فرنگی کاهو پیاز خیار فلفل دلمه ای پنیر فتا']
	],
	'کیک': [
		['کیک روز' , '۵۰' , ''],
		['اوت میل' , '۸۰' , 'شیر داغ اوت میل تکه های میوه'],
		['چیز کیک' , '۶۵' , '']
	],
	'سرویس قلیان':  [
		['قلیان لاو' , '۱۵۰' , ''],
		['قلیان مسکو' , '۱۵۰' , ''],
		['قلیان پرتغال نعنا' , '۱۳۰' , ''],
		['قلیان بلوبری' , '۱۳۰' , ''],
		['قلیان هندوانه یخ' , '۱۳۰' , ''],
		['قلیان آدامس دارچین' , '۱۳۰' , ''],
		['قلیان دو سیب' , '۱۳۰' , ''],
		['قلیان آلبالو' , '۱۳۰' , ''],
		['قلیان دو سیب آلبالو' , '۱۳۰' , ''],
		['چای کیک و روز' , '۸۰' , ''],
		['چای و نبات' , '۵۰' , ''],
		['دمنوش مخصوص باغ کافه' , '۵۰' , ''],
	],
}

import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js"
import { getDatabase , ref , onValue} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-database.js"


 const firebaseConfig = {
    apiKey: "AIzaSyAACHfO7Q5z8APs1EOZ1xnlBcz4egJXmjQ",
    authDomain: "parham-5a853.firebaseapp.com",
    databaseURL: "https://parham-5a853-default-rtdb.firebaseio.com/",
    projectId: "parham-5a853",
    storageBucket: "parham-5a853.firebasestorage.app",
    messagingSenderId: "204963556446",
    appId: "1:204963556446:web:2c1a9a7bbcb217fa6bd8cf",
    measurementId: "G-L5WQLVZX4Y"
  };

  const app = initializeApp(firebaseConfig);
  const database = getDatabase(app);

const menuRef = ref(database , 'menu')
onValue(menuRef, (snapshot) => {
	const menu = snapshot.val();
	console.log(menu)
})

// for here code begins :DD

const container = document.getElementById('container')

let selectedMenu = 'نوشیدنی گرم'

function ce (elem , className) {
	const e = document.createElement(elem)
	e.classList.add(className)

	return e
}

function changeMenu (event) {
	const target = event.target

	const targetView = document.querySelector('.line')

	if (target.children[0]) {
		if (target.children[0].tagName == 'SPAN') {
			selectedMenu = target.children[0].textContent
			targetView.scrollIntoView({behavior: 'smooth'})
		}
	}
	else {
		selectedMenu = target.textContent
		targetView.scrollIntoView({behavior: 'smooth'})
	}
	createMenuItems(selectedMenu)
}

function createLOGO () {
	const div = ce('div' , 'imageHoler')
	div.innerHTML = 'باغ </br> کافه'
	container.append(div)
}

function createMenuHeaders() {
	const mainDiv = ce('div' , 'menuHeaders')
	mainDiv.addEventListener('click' , changeMenu)
	for (let header in menu) {
		const div = ce('div', 'menuOneHeader')

		const title = ce('span', 'menuTitle')
		title.textContent = header

		div.append(title)

		mainDiv.append(div)
	}
	container.append(mainDiv)
}

function createLine () {
	const div = ce('div', 'line')

	container.append(div)
}

function createMenuItems () {
	if (document.querySelector('.menuItmes')) {
		document.querySelector('.menuItmes').remove()
	}
	const mainDiv = ce('div', 'menuItmes')
	
	let menuItems = menu[selectedMenu]
	
	menuItems.forEach((item) => {
		const itemDiv = ce('div', 'menuOneItem')

		const image = ce('div', 'foodImage')

		const infoDiv = ce('div', 'menuOneItemInfo')

		const upperDiv = ce('div', 'menuOneItemInfoUpper')
		const title = ce('span' , 'foodTitle')
		title.textContent = item[0]

		const price = ce('span' , 'footPrice')
		price.textContent = item[1]

		const lowerDiv = ce('div' , 'menuOneItemInfoLower')
		const desc = ce('span' , 'foodDesc')
		desc.textContent = item[2]

		upperDiv.append(title)
		upperDiv.append(price)
		infoDiv.append(upperDiv)

		lowerDiv.append(desc)
		infoDiv.append(lowerDiv)

		// itemDiv.append(image)
		itemDiv.append(infoDiv)

		mainDiv.append(itemDiv)
	})
	container.append(mainDiv)
}

createLOGO()
createMenuHeaders()
createLine()
createMenuItems()